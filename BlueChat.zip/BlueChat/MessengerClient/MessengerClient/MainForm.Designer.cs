﻿namespace MessengerClient
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pnlChatContainer = new System.Windows.Forms.Panel();
            this.pnlMessageUnderline = new System.Windows.Forms.Panel();
            this.btnFile = new System.Windows.Forms.Button();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.txtChat = new System.Windows.Forms.TextBox();
            this.pnlOnlineUsersContainer = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnEndCall = new System.Windows.Forms.Button();
            this.btnVideoCall = new System.Windows.Forms.Button();
            this.cmbCameras = new System.Windows.Forms.ComboBox();
            this.lstOnlineUsers = new System.Windows.Forms.ListBox();
            this.lblOnlineUsers = new System.Windows.Forms.Label();
            this.pnlVideoContainer = new System.Windows.Forms.Panel();
            this.lblVideo = new System.Windows.Forms.Label();
            this.videoPictureBox = new System.Windows.Forms.PictureBox();
            this.localVideoPictureBox = new System.Windows.Forms.PictureBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.pnlHeader.SuspendLayout();
            this.pnlChatContainer.SuspendLayout();
            this.pnlOnlineUsersContainer.SuspendLayout();
            this.pnlVideoContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.videoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.localVideoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Controls.Add(this.btnMinimize);
            this.pnlHeader.Controls.Add(this.btnClose);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(1200, 50);
            this.pnlHeader.TabIndex = 0;
            this.pnlHeader.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlHeader_MouseDown);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Nirmala UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.lblTitle.Location = new System.Drawing.Point(15, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(132, 37);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "BlueChat";
            // 
            // btnMinimize
            // 
            this.btnMinimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.btnMinimize.ForeColor = System.Drawing.Color.White;
            this.btnMinimize.Location = new System.Drawing.Point(1100, 0);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(50, 50);
            this.btnMinimize.TabIndex = 2;
            this.btnMinimize.Text = "─";
            this.btnMinimize.UseVisualStyleBackColor = true;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            this.btnMinimize.MouseEnter += new System.EventHandler(this.btnMinimize_MouseEnter);
            this.btnMinimize.MouseLeave += new System.EventHandler(this.btnMinimize_MouseLeave);
            // 
            // btnClose
            // 
            this.btnClose.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1150, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 50);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "✕";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseEnter += new System.EventHandler(this.btnClose_MouseEnter);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            // 
            // pnlChatContainer
            // 
            this.pnlChatContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.pnlChatContainer.Controls.Add(this.pnlMessageUnderline);
            this.pnlChatContainer.Controls.Add(this.btnFile);
            this.pnlChatContainer.Controls.Add(this.btnSend);
            this.pnlChatContainer.Controls.Add(this.txtMessage);
            this.pnlChatContainer.Controls.Add(this.txtChat);
            this.pnlChatContainer.Location = new System.Drawing.Point(20, 70);
            this.pnlChatContainer.Name = "pnlChatContainer";
            this.pnlChatContainer.Size = new System.Drawing.Size(600, 500);
            this.pnlChatContainer.TabIndex = 1;
            // 
            // pnlMessageUnderline
            // 
            this.pnlMessageUnderline.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.pnlMessageUnderline.Location = new System.Drawing.Point(10, 450);
            this.pnlMessageUnderline.Name = "pnlMessageUnderline";
            this.pnlMessageUnderline.Size = new System.Drawing.Size(480, 2);
            this.pnlMessageUnderline.TabIndex = 4;
            // 
            // btnFile
            // 
            this.btnFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.btnFile.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFile.Font = new System.Drawing.Font("Nirmala UI", 10F);
            this.btnFile.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnFile.Location = new System.Drawing.Point(500, 460);
            this.btnFile.Name = "btnFile";
            this.btnFile.Size = new System.Drawing.Size(90, 32);
            this.btnFile.TabIndex = 3;
            this.btnFile.Text = "📎 Файл";
            this.btnFile.UseVisualStyleBackColor = false;
            this.btnFile.Click += new System.EventHandler(this.btnFile_Click);
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnSend.FlatAppearance.BorderSize = 0;
            this.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSend.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSend.ForeColor = System.Drawing.Color.White;
            this.btnSend.Location = new System.Drawing.Point(500, 420);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(90, 32);
            this.btnSend.TabIndex = 2;
            this.btnSend.Text = "Надіслати";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtMessage
            // 
            this.txtMessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.txtMessage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMessage.Font = new System.Drawing.Font("Nirmala UI", 10F);
            this.txtMessage.ForeColor = System.Drawing.Color.White;
            this.txtMessage.Location = new System.Drawing.Point(10, 420);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(480, 23);
            this.txtMessage.TabIndex = 1;
            this.txtMessage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMessage_KeyPress);
            // 
            // txtChat
            // 
            this.txtChat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.txtChat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtChat.Font = new System.Drawing.Font("Nirmala UI", 10F);
            this.txtChat.ForeColor = System.Drawing.Color.White;
            this.txtChat.Location = new System.Drawing.Point(10, 10);
            this.txtChat.Multiline = true;
            this.txtChat.Name = "txtChat";
            this.txtChat.ReadOnly = true;
            this.txtChat.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtChat.Size = new System.Drawing.Size(580, 400);
            this.txtChat.TabIndex = 0;
            this.txtChat.DoubleClick += new System.EventHandler(this.txtChat_DoubleClick);
            this.txtChat.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtChat_MouseMove);
            // 
            // pnlOnlineUsersContainer
            // 
            this.pnlOnlineUsersContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.pnlOnlineUsersContainer.Controls.Add(this.btnLogout);
            this.pnlOnlineUsersContainer.Controls.Add(this.btnEndCall);
            this.pnlOnlineUsersContainer.Controls.Add(this.btnVideoCall);
            this.pnlOnlineUsersContainer.Controls.Add(this.cmbCameras);
            this.pnlOnlineUsersContainer.Controls.Add(this.lstOnlineUsers);
            this.pnlOnlineUsersContainer.Controls.Add(this.lblOnlineUsers);
            this.pnlOnlineUsersContainer.Location = new System.Drawing.Point(640, 70);
            this.pnlOnlineUsersContainer.Name = "pnlOnlineUsersContainer";
            this.pnlOnlineUsersContainer.Size = new System.Drawing.Size(250, 500);
            this.pnlOnlineUsersContainer.TabIndex = 2;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.btnLogout.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Nirmala UI", 10F);
            this.btnLogout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnLogout.Location = new System.Drawing.Point(10, 370);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(230, 35);
            this.btnLogout.TabIndex = 5;
            this.btnLogout.Text = "🚪 Вийти";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnEndCall
            // 
            this.btnEndCall.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            this.btnEndCall.FlatAppearance.BorderSize = 0;
            this.btnEndCall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEndCall.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnEndCall.ForeColor = System.Drawing.Color.White;
            this.btnEndCall.Location = new System.Drawing.Point(10, 330);
            this.btnEndCall.Name = "btnEndCall";
            this.btnEndCall.Size = new System.Drawing.Size(230, 35);
            this.btnEndCall.TabIndex = 4;
            this.btnEndCall.Text = "📞 Завершити дзвінок";
            this.btnEndCall.UseVisualStyleBackColor = false;
            this.btnEndCall.Click += new System.EventHandler(this.btnEndCall_Click);
            // 
            // btnVideoCall
            // 
            this.btnVideoCall.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnVideoCall.FlatAppearance.BorderSize = 0;
            this.btnVideoCall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVideoCall.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnVideoCall.ForeColor = System.Drawing.Color.White;
            this.btnVideoCall.Location = new System.Drawing.Point(10, 290);
            this.btnVideoCall.Name = "btnVideoCall";
            this.btnVideoCall.Size = new System.Drawing.Size(230, 35);
            this.btnVideoCall.TabIndex = 3;
            this.btnVideoCall.Text = "📹 Відеодзвінок";
            this.btnVideoCall.UseVisualStyleBackColor = false;
            this.btnVideoCall.Click += new System.EventHandler(this.btnVideoCall_Click);
            // 
            // cmbCameras
            // 
            this.cmbCameras.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.cmbCameras.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCameras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCameras.Font = new System.Drawing.Font("Nirmala UI", 10F);
            this.cmbCameras.ForeColor = System.Drawing.Color.White;
            this.cmbCameras.FormattingEnabled = true;
            this.cmbCameras.Location = new System.Drawing.Point(10, 250);
            this.cmbCameras.Name = "cmbCameras";
            this.cmbCameras.Size = new System.Drawing.Size(230, 31);
            this.cmbCameras.TabIndex = 2;
            // 
            // lstOnlineUsers
            // 
            this.lstOnlineUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lstOnlineUsers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstOnlineUsers.Font = new System.Drawing.Font("Nirmala UI", 10F);
            this.lstOnlineUsers.ForeColor = System.Drawing.Color.White;
            this.lstOnlineUsers.FormattingEnabled = true;
            this.lstOnlineUsers.ItemHeight = 23;
            this.lstOnlineUsers.Items.AddRange(new object[] {
            "Завантаження..."});
            this.lstOnlineUsers.Location = new System.Drawing.Point(10, 40);
            this.lstOnlineUsers.Name = "lstOnlineUsers";
            this.lstOnlineUsers.Size = new System.Drawing.Size(230, 184);
            this.lstOnlineUsers.TabIndex = 1;
            this.lstOnlineUsers.DoubleClick += new System.EventHandler(this.lstOnlineUsers_DoubleClick);
            // 
            // lblOnlineUsers
            // 
            this.lblOnlineUsers.AutoSize = true;
            this.lblOnlineUsers.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblOnlineUsers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.lblOnlineUsers.Location = new System.Drawing.Point(10, 10);
            this.lblOnlineUsers.Name = "lblOnlineUsers";
            this.lblOnlineUsers.Size = new System.Drawing.Size(229, 28);
            this.lblOnlineUsers.TabIndex = 0;
            this.lblOnlineUsers.Text = "Онлайн користувачі";
            // 
            // pnlVideoContainer
            // 
            this.pnlVideoContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.pnlVideoContainer.Controls.Add(this.lblVideo);
            this.pnlVideoContainer.Controls.Add(this.videoPictureBox);
            this.pnlVideoContainer.Controls.Add(this.localVideoPictureBox);
            this.pnlVideoContainer.Location = new System.Drawing.Point(900, 70);
            this.pnlVideoContainer.Name = "pnlVideoContainer";
            this.pnlVideoContainer.Size = new System.Drawing.Size(280, 400);
            this.pnlVideoContainer.TabIndex = 3;
            // 
            // lblVideo
            // 
            this.lblVideo.AutoSize = true;
            this.lblVideo.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblVideo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.lblVideo.Location = new System.Drawing.Point(10, 10);
            this.lblVideo.Name = "lblVideo";
            this.lblVideo.Size = new System.Drawing.Size(153, 28);
            this.lblVideo.TabIndex = 2;
            this.lblVideo.Text = "Відеодзвінок";
            // 
            // videoPictureBox
            // 
            this.videoPictureBox.BackColor = System.Drawing.Color.Black;
            this.videoPictureBox.Location = new System.Drawing.Point(10, 40);
            this.videoPictureBox.Name = "videoPictureBox";
            this.videoPictureBox.Size = new System.Drawing.Size(260, 170);
            this.videoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.videoPictureBox.TabIndex = 0;
            this.videoPictureBox.TabStop = false;
            // 
            // localVideoPictureBox
            // 
            this.localVideoPictureBox.BackColor = System.Drawing.Color.Black;
            this.localVideoPictureBox.Location = new System.Drawing.Point(10, 220);
            this.localVideoPictureBox.Name = "localVideoPictureBox";
            this.localVideoPictureBox.Size = new System.Drawing.Size(260, 170);
            this.localVideoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.localVideoPictureBox.TabIndex = 1;
            this.localVideoPictureBox.TabStop = false;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Nirmala UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            this.lblStatus.Location = new System.Drawing.Point(905, 488);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(204, 25);
            this.lblStatus.TabIndex = 4;
            this.lblStatus.Text = "Статус: Відключено";
            // 
            // MainForm
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1200, 700);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pnlVideoContainer);
            this.Controls.Add(this.pnlOnlineUsersContainer);
            this.Controls.Add(this.pnlChatContainer);
            this.Controls.Add(this.pnlHeader);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BlueChat";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.pnlChatContainer.ResumeLayout(false);
            this.pnlChatContainer.PerformLayout();
            this.pnlOnlineUsersContainer.ResumeLayout(false);
            this.pnlOnlineUsersContainer.PerformLayout();
            this.pnlVideoContainer.ResumeLayout(false);
            this.pnlVideoContainer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.videoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.localVideoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel pnlChatContainer;
        private System.Windows.Forms.Panel pnlMessageUnderline;
        private System.Windows.Forms.Button btnFile;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.TextBox txtChat;
        private System.Windows.Forms.Panel pnlOnlineUsersContainer;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnEndCall;
        private System.Windows.Forms.Button btnVideoCall;
        private System.Windows.Forms.ComboBox cmbCameras;
        private System.Windows.Forms.ListBox lstOnlineUsers;
        private System.Windows.Forms.Label lblOnlineUsers;
        private System.Windows.Forms.Panel pnlVideoContainer;
        private System.Windows.Forms.Label lblVideo;
        private System.Windows.Forms.PictureBox videoPictureBox;
        private System.Windows.Forms.PictureBox localVideoPictureBox;
        private System.Windows.Forms.Label lblStatus;
    }
}