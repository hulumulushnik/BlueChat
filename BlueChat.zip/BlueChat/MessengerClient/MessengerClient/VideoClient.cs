﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace MessengerClient
{
    public class VideoClient : IDisposable
    {
        private PictureBox _pictureBox;
        private UdpClient _udpClient;
        private bool _isReceiving;
        private Thread _receiveThread;
        private int _port;

        public VideoClient(PictureBox pictureBox, string username)
        {
            _pictureBox = pictureBox;

            // Генеруємо унікальний порт для отримання
            _port = 12000 + Math.Abs(username.GetHashCode() % 1000);

            StartReceiving();
        }

        private void StartReceiving()
        {
            try
            {
                _udpClient = new UdpClient();
                _udpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

                // Підписуємося на multicast групу
                _udpClient.JoinMulticastGroup(IPAddress.Parse("239.0.0.1"));
                _udpClient.Client.Bind(new IPEndPoint(IPAddress.Any, _port));

                _isReceiving = true;
                _receiveThread = new Thread(ReceiveVideo);
                _receiveThread.IsBackground = true;
                _receiveThread.Start();

                Console.WriteLine($"🎥 Відеоклієнт запущено на порті {_port}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка запуску відеоклієнта: {ex.Message}");
            }
        }

        private void ReceiveVideo()
        {
            while (_isReceiving)
            {
                try
                {
                    IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);
                    byte[] data = _udpClient.Receive(ref remoteEndPoint);

                    if (data.Length > 4)
                    {
                        // Обробка відеоданих
                        byte[] jpegData = new byte[data.Length - 4];
                        Buffer.BlockCopy(data, 4, jpegData, 0, jpegData.Length);

                        UpdateVideoFrame(jpegData);
                    }
                }
                catch (Exception ex)
                {
                    if (_isReceiving)
                        Console.WriteLine($"❌ Помилка отримання відео: {ex.Message}");
                }
            }
        }

        private void UpdateVideoFrame(byte[] jpegData)
        {
            if (_pictureBox.InvokeRequired)
            {
                _pictureBox.Invoke(new Action<byte[]>(UpdateVideoFrame), jpegData);
                return;
            }

            try
            {
                using (var ms = new MemoryStream(jpegData))
                {
                    var image = Image.FromStream(ms);
                    var oldImage = _pictureBox.Image;
                    _pictureBox.Image = new Bitmap(image);
                    oldImage?.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка оновлення відео: {ex.Message}");
            }
        }

        public void Dispose()
        {
            _isReceiving = false;
            _udpClient?.Close();
            _receiveThread?.Join(1000);
        }
    }
}