﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace MessengerClient
{
    public partial class LoginForm : Form
    {
        // === Властивості даних ===
        public string Username { get; private set; } = "";
        public string Password { get; private set; } = "";
        public string ServerIP { get; private set; } = "127.0.0.1";
        public bool IsRegistration { get; private set; } = false;

        // === Константи кольорів (BlueChat Theme) ===
        private readonly Color clrBackground = Color.FromArgb(46, 51, 73);
        private readonly Color clrHeader = Color.FromArgb(24, 30, 54);
        private readonly Color clrAccent = Color.FromArgb(0, 126, 249);
        private readonly Color clrText = Color.FromArgb(200, 200, 200);
        private readonly Color clrTextActive = Color.White;

        public LoginForm()
        {
            InitializeComponent();
        }

        // === WinAPI для перетягування вікна ===
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        // === Обробники подій ===
        private void pnlHeader_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.BackColor = Color.Red;
        }

        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.BackColor = clrHeader;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                Username = txtUsername.Text;
                Password = txtPassword.Text;
                ServerIP = txtServerIP.Text;
                IsRegistration = false;
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                Username = txtUsername.Text;
                Password = txtPassword.Text;
                ServerIP = txtServerIP.Text;
                IsRegistration = true;
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private bool ValidateInput()
        {
            // Скидаємо кольори ліній на сірий перед перевіркою
            pnlUsernameUnderline.BackColor = clrText;
            pnlPasswordUnderline.BackColor = clrText;

            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                pnlUsernameUnderline.BackColor = Color.Red;
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                pnlPasswordUnderline.BackColor = Color.Red;
                isValid = false;
            }

            if (!isValid)
            {
                MessageBox.Show("Будь ласка, заповніть всі поля!", "Помилка входу",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            return isValid;
        }
    }
}