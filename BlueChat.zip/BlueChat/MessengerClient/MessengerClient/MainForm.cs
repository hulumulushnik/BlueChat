﻿using AForge.Video;
using AForge.Video.DirectShow;
using MessengerClient.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Message = MessengerClient.Models.Message;

namespace MessengerClient
{
    public partial class MainForm : Form
    {
        // === Константи кольорів (BlueChat Theme) ===
        private readonly Color clrBackground = Color.FromArgb(46, 51, 73);
        private readonly Color clrHeader = Color.FromArgb(24, 30, 54);
        private readonly Color clrAccent = Color.FromArgb(0, 126, 249);
        private readonly Color clrText = Color.FromArgb(200, 200, 200);
        private readonly Color clrTextActive = Color.White;
        private readonly Color clrPanel = Color.FromArgb(37, 42, 64);
        private readonly Color clrOnline = Color.FromArgb(76, 175, 80);
        private readonly Color clrOffline = Color.FromArgb(244, 67, 54);

        private TcpClient _client;
        private NetworkStream _stream;
        private string _username = "";
        private bool _isConnected = false;
        private VideoClient _videoClient;
        private string _currentCallWith = "";

        private List<FileLink> _fileLinks = new List<FileLink>();
        private User _currentUser;
        private List<User> _onlineUsers = new List<User>();
        private List<Message> _messageHistory = new List<Message>();

        // Вебкамера
        private FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoSource;
        private bool _isCapturingVideo = false;

        private class FileLink
        {
            public int StartPosition { get; set; }
            public int EndPosition { get; set; }
            public FileMessage FileMessage { get; set; }
        }

        public MainForm()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        // === WinAPI для перетягування вікна ===
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        // === Обробники подій для кнопок заголовка ===
        private void pnlHeader_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimize_MouseEnter(object sender, EventArgs e)
        {
            btnMinimize.BackColor = Color.FromArgb(60, 70, 100);
        }

        private void btnMinimize_MouseLeave(object sender, EventArgs e)
        {
            btnMinimize.BackColor = clrHeader;
        }

        private void btnClose_MouseEnter(object sender, EventArgs e)
        {
            btnClose.BackColor = Color.Red;
        }

        private void btnClose_MouseLeave(object sender, EventArgs e)
        {
            btnClose.BackColor = clrHeader;
        }

        // === Решта коду (функціонал) ===

        private void MainForm_Load(object sender, EventArgs e)
        {
            InitializeCamera();
            ShowLoginForm();
        }

        private void InitializeCamera()
        {
            try
            {
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                if (videoDevices.Count == 0)
                {
                    MessageBox.Show("Вебкамера не знайдена", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                foreach (FilterInfo device in videoDevices)
                {
                    cmbCameras.Items.Add(device.Name);
                }

                if (cmbCameras.Items.Count > 0)
                {
                    cmbCameras.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка ініціалізації камери: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Ви дійсно хочете вийти?", "Підтвердження",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                LogoutAndReturnToLogin();
            }
        }

        private void LogoutAndReturnToLogin()
        {
            try
            {
                if (_isConnected && _currentUser != null)
                {
                    var logoutPacket = new NetworkPacket("Logout", _currentUser);
                    byte[] data = NetworkSerializer.Serialize(logoutPacket);
                    _stream.Write(data, 0, data.Length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка відправки logout: {ex.Message}");
            }
            finally
            {
                _isConnected = false;
                _stream?.Close();
                _client?.Close();
                StopVideoCapture();

                this.Hide();
                LoginForm loginForm = new LoginForm();
                if (loginForm.ShowDialog() == DialogResult.OK)
                {
                    this.Close();
                }
                else
                {
                    Application.Exit();
                }
            }
        }

        private void txtChat_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                int cursorPosition = txtChat.SelectionStart;
                FileLink clickedFile = _fileLinks.Find(link =>
                    cursorPosition >= link.StartPosition && cursorPosition <= link.EndPosition);

                if (clickedFile != null)
                {
                    ShowFileOptions(clickedFile.FileMessage);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка обробки подвійного кліку: {ex.Message}");
            }
        }

        private void txtChat_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                int charIndex = txtChat.GetCharIndexFromPosition(e.Location);
                bool isOverFile = _fileLinks.Any(link =>
                    charIndex >= link.StartPosition && charIndex <= link.EndPosition);
                txtChat.Cursor = isOverFile ? Cursors.Hand : Cursors.Default;
            }
            catch { }
        }

        private void ShowFileOptions(FileMessage fileMessage)
        {
            ContextMenuStrip menu = new ContextMenuStrip();
            menu.BackColor = clrBackground;
            menu.ForeColor = clrTextActive;

            ToolStripMenuItem openItem = new ToolStripMenuItem("Відкрити файл");
            openItem.Click += (s, e) => OpenFile(fileMessage);
            menu.Items.Add(openItem);

            ToolStripMenuItem saveItem = new ToolStripMenuItem("Скачати файл");
            saveItem.Click += (s, e) => SaveFileWithDialog(fileMessage);
            menu.Items.Add(saveItem);

            ToolStripMenuItem copyItem = new ToolStripMenuItem("Копіювати назву");
            copyItem.Click += (s, e) => Clipboard.SetText(fileMessage.FileName);
            menu.Items.Add(copyItem);

            menu.Show(txtChat, txtChat.PointToClient(Cursor.Position));
        }

        private void OpenFile(FileMessage fileMessage)
        {
            try
            {
                string tempPath = Path.GetTempPath();
                string tempFile = Path.Combine(tempPath, fileMessage.FileName);
                File.WriteAllBytes(tempFile, fileMessage.FileData);
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = tempFile,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не вдалося відкрити файл: {ex.Message}", "Помилка");
            }
        }

        private void SaveFile(FileMessage fileMessage)
        {
            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.FileName = fileMessage.FileName;
                saveDialog.Filter = "Всі файли (*.*)|*.*";
                saveDialog.Title = "Зберегти файл";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllBytes(saveDialog.FileName, fileMessage.FileData);
                        MessageBox.Show($"Файл збережено: {saveDialog.FileName}", "Успіх");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Помилка збереження: {ex.Message}", "Помилка");
                    }
                }
            }
        }

        private void StartVideoCapture()
        {
            if (videoDevices == null || videoDevices.Count == 0)
            {
                MessageBox.Show("Вебкамера не знайдена", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                videoSource = new VideoCaptureDevice(videoDevices[cmbCameras.SelectedIndex].MonikerString);
                videoSource.NewFrame += new NewFrameEventHandler(videoSource_NewFrame);
                videoSource.Start();

                _isCapturingVideo = true;
                localVideoPictureBox.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка запуску камери: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void videoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            try
            {
                Bitmap frame = (Bitmap)eventArgs.Frame.Clone();
                UpdateLocalVideo(frame);

                if (_videoClient != null && !string.IsNullOrEmpty(_currentCallWith) && _isCapturingVideo)
                {
                    byte[] jpegData = ImageToJpeg(frame);
                    SendVideoFrame(jpegData);
                }

                frame.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка обробки кадру: {ex.Message}");
            }
        }

        private void SendVideoFrame(byte[] jpegData)
        {
            try
            {
                const int MaxPacketSize = 65000;
                const string MulticastGroup = "239.0.0.1";

                int basePort = 11000 + Math.Abs(_username.GetHashCode() % 1000);
                int port = basePort;

                int totalPackets = (int)Math.Ceiling((double)jpegData.Length / (MaxPacketSize - 4));

                for (int packetIndex = 0; packetIndex < totalPackets; packetIndex++)
                {
                    int offset = packetIndex * (MaxPacketSize - 4);
                    int length = Math.Min(MaxPacketSize - 4, jpegData.Length - offset);

                    byte[] packetData = new byte[length + 4];
                    packetData[0] = (byte)packetIndex;

                    Buffer.BlockCopy(jpegData, offset, packetData, 4, length);

                    IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(MulticastGroup), port);

                    using (UdpClient sendClient = new UdpClient())
                    {
                        sendClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                        sendClient.Send(packetData, packetData.Length, endPoint);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка відправки відео: {ex.Message}");
            }
        }

        private byte[] ImageToJpeg(Image image)
        {
            try
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    var encoderParameters = new EncoderParameters(1);
                    encoderParameters.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 50L);
                    var jpegCodec = GetEncoder(ImageFormat.Jpeg);
                    image.Save(memoryStream, jpegCodec, encoderParameters);
                    return memoryStream.ToArray();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка конвертації в JPEG: {ex.Message}");
                return new byte[0];
            }
        }

        private ImageCodecInfo GetEncoder(ImageFormat format)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                    return codec;
            }
            return null;
        }

        private void UpdateLocalVideo(Image image)
        {
            if (localVideoPictureBox.InvokeRequired)
            {
                localVideoPictureBox.Invoke(new Action<Image>(UpdateLocalVideo), image);
            }
            else
            {
                if (!localVideoPictureBox.IsDisposed && localVideoPictureBox.Visible)
                {
                    Image oldImage = localVideoPictureBox.Image;
                    localVideoPictureBox.Image = new Bitmap(image);
                    oldImage?.Dispose();
                }
            }
        }

        private void StartVideoCall(string targetUser)
        {
            try
            {
                _currentCallWith = targetUser;
                videoPictureBox.Visible = true;
                localVideoPictureBox.Visible = true;
                btnEndCall.Enabled = true;
                btnVideoCall.Enabled = false;

                _videoClient = new VideoClient(videoPictureBox, _username);
                StartVideoCapture();

                Console.WriteLine($"🎥 Відеодзвінок з {targetUser} розпочато");
                AddSystemMessage($"Відеодзвінок з {targetUser} розпочато");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка запуску відеодзвінка: {ex.Message}");
                MessageBox.Show($"Помилка запуску камери: {ex.Message}", "Помилка");
            }
        }

        private void StopVideoCall()
        {
            try
            {
                _currentCallWith = "";
                videoPictureBox.Visible = false;
                localVideoPictureBox.Visible = false;
                btnEndCall.Enabled = false;
                btnVideoCall.Enabled = true;

                StopVideoCapture();

                if (_videoClient != null)
                {
                    _videoClient.Dispose();
                    _videoClient = null;
                }

                Console.WriteLine("🎥 Відеодзвінок завершено");
                AddSystemMessage("Відеодзвінок завершено");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка завершення дзвінка: {ex.Message}");
            }
        }

        private void StopVideoCapture()
        {
            _isCapturingVideo = false;

            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                videoSource.WaitForStop();
                videoSource.NewFrame -= new NewFrameEventHandler(videoSource_NewFrame);
                videoSource = null;
                Console.WriteLine("Камера зупинена");
            }
        }

        private void ShowLoginForm()
        {
            using (LoginForm loginForm = new LoginForm())
            {
                if (loginForm.ShowDialog() == DialogResult.OK)
                {
                    _username = loginForm.Username;
                    TryRegisterAndLogin(loginForm.ServerIP, loginForm.Username, loginForm.Password);
                }
                else
                {
                    Close();
                }
            }
        }

        private void ConnectToServer(string serverIP, string username, string password)
        {
            try
            {
                Console.WriteLine($"Спроба підключення до {serverIP}:8888...");
                _client = new TcpClient();
                _client.Connect(serverIP, 8888);
                _stream = _client.GetStream();
                _isConnected = true;

                Console.WriteLine("Підключення успішне, створюємо login data...");
                var loginData = new
                {
                    Username = username,
                    Password = password
                };

                var loginPacket = new NetworkPacket("Login", loginData);
                byte[] data = NetworkSerializer.Serialize(loginPacket);

                Console.WriteLine($"Відправляємо login пакет ({data.Length} байт)...");
                _stream.Write(data, 0, data.Length);
                Console.WriteLine("Login пакет відправлено");

                _username = username;

                Thread receiveThread = new Thread(ReceiveData);
                receiveThread.IsBackground = true;
                receiveThread.Start();
                Console.WriteLine("Потік отримання даних запущено");

                this.Text = $"BlueChat - {username}";
                btnSend.Enabled = true;
                btnFile.Enabled = true;
                btnVideoCall.Enabled = true;

                UpdateStatus("Підключено");
                AddSystemMessage("Підключено до сервера");
                Console.WriteLine("UI оновлено");

                System.Threading.Timer timer = new System.Threading.Timer(state =>
                {
                    if (_isConnected && _stream != null)
                    {
                        Console.WriteLine("⏰ Таймер: запитуємо онлайн користувачів...");
                        RequestOnlineUsers();
                    }
                }, null, 2000, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                UpdateStatus("Відключено");
                Console.WriteLine($"ПОМИЛКА підключення: {ex.Message}");
                MessageBox.Show($"Помилка підключення: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
        }

        private void UpdateStatus(string status)
        {
            if (lblStatus.InvokeRequired)
            {
                lblStatus.Invoke(new Action<string>(UpdateStatus), status);
            }
            else
            {
                lblStatus.Text = $"Статус: {status}";
                lblStatus.ForeColor = status.Contains("Підключено") ? clrOnline : clrOffline;
            }
        }

        private void ReceiveData()
        {
            byte[] buffer = new byte[4096];
            StringBuilder jsonBuilder = new StringBuilder();
            Console.WriteLine("📡 ReceiveData поток запущено");

            while (_isConnected && _client != null && _client.Connected)
            {
                try
                {
                    if (!_stream.DataAvailable)
                    {
                        Thread.Sleep(50);
                        continue;
                    }

                    int bytesRead = _stream.Read(buffer, 0, buffer.Length);
                    Console.WriteLine($"📨 Отримано {bytesRead} байт від сервера");

                    if (bytesRead == 0)
                    {
                        Console.WriteLine("❌ Сервер відключився (0 bytes)");
                        HandleDisconnection();
                        break;
                    }

                    if (bytesRead > 0)
                    {
                        string receivedData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        jsonBuilder.Append(receivedData);

                        string jsonString = jsonBuilder.ToString();
                        int startIndex = 0;

                        while (startIndex < jsonString.Length)
                        {
                            int objectStart = jsonString.IndexOf('{', startIndex);
                            if (objectStart == -1) break;

                            int braceCount = 0;
                            int objectEnd = -1;

                            for (int i = objectStart; i < jsonString.Length; i++)
                            {
                                if (jsonString[i] == '{') braceCount++;
                                else if (jsonString[i] == '}') braceCount--;

                                if (braceCount == 0)
                                {
                                    objectEnd = i;
                                    break;
                                }
                            }

                            if (objectEnd == -1) break;

                            string singleJson = jsonString.Substring(objectStart, objectEnd - objectStart + 1);
                            startIndex = objectEnd + 1;

                            try
                            {
                                Console.WriteLine($"📝 Обробка JSON: {singleJson}");
                                var packet = NetworkSerializer.Deserialize<NetworkPacket>(singleJson);

                                if (packet == null)
                                {
                                    Console.WriteLine("❌ Десеріалізація повернула null");
                                    continue;
                                }

                                Console.WriteLine($"✅ Успішно десеріалізовано пакет типу: {packet.Type}");
                                ProcessReceivedPacket(packet);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"❌ Помилка десеріалізації: {ex.Message}");
                            }
                        }

                        if (startIndex < jsonString.Length)
                        {
                            jsonBuilder = new StringBuilder(jsonString.Substring(startIndex));
                        }
                        else
                        {
                            jsonBuilder.Clear();
                        }
                    }
                }
                catch (IOException ioEx)
                {
                    Console.WriteLine($"❌ IO помилка: {ioEx.Message}");
                    HandleDisconnection();
                    break;
                }
                catch (ObjectDisposedException)
                {
                    Console.WriteLine("❌ Stream вже видалений");
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Загальна помилка отримання: {ex.Message}");
                }
            }
            Console.WriteLine("📡 ReceiveData поток завершено");
        }

        private void HandleDisconnection()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(HandleDisconnection));
                return;
            }

            _isConnected = false;
            UpdateStatus("Відключено");
            AddSystemMessage("Відключено від сервера");

            btnSend.Enabled = false;
            btnFile.Enabled = false;
            btnVideoCall.Enabled = false;
        }

        private void UpdateOnlineUsersFromString(string usersString)
        {
            try
            {
                Console.WriteLine($"🔄 Оновлення списку онлайн: '{usersString}'");

                if (string.IsNullOrEmpty(usersString) || string.IsNullOrWhiteSpace(usersString))
                {
                    lstOnlineUsers.Items.Clear();
                    lstOnlineUsers.Items.Add("❌ Немає онлайн користувачів");
                    lstOnlineUsers.BackColor = clrBackground;
                    lstOnlineUsers.ForeColor = clrText;
                    Console.WriteLine("📭 Список онлайн порожній");
                    return;
                }

                var usernames = usersString.Split(',')
                                          .Where(u => !string.IsNullOrEmpty(u?.Trim()))
                                          .Select(u => u.Trim())
                                          .ToList();

                Console.WriteLine($"👥 Знайдено імен: {usernames.Count} - {string.Join(", ", usernames)}");

                lstOnlineUsers.Items.Clear();

                if (usernames.Count == 0 || (usernames.Count == 1 && string.IsNullOrEmpty(usernames[0])))
                {
                    lstOnlineUsers.Items.Add("❌ Немає онлайн користувачів");
                    lstOnlineUsers.BackColor = clrBackground;
                    lstOnlineUsers.ForeColor = clrText;
                }
                else
                {
                    lstOnlineUsers.BackColor = clrBackground;
                    lstOnlineUsers.ForeColor = clrTextActive;
                    bool foundUsers = false;

                    foreach (var username in usernames)
                    {
                        if (!string.IsNullOrEmpty(username))
                        {
                            string status = username == _username ? " (Ви) 🟢" : " 🟢";
                            string itemText = $"{username}{status}";
                            lstOnlineUsers.Items.Add(itemText);
                            Console.WriteLine($"✅ Додано в список: {itemText}");
                            foundUsers = true;
                        }
                    }

                    if (!foundUsers)
                    {
                        lstOnlineUsers.Items.Add("❌ Немає онлайн користувачів");
                        lstOnlineUsers.BackColor = clrBackground;
                        lstOnlineUsers.ForeColor = clrText;
                    }
                }

                Console.WriteLine($"📊 Оновлено список онлайн. Всього: {lstOnlineUsers.Items.Count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка оновлення онлайн користувачів: {ex.Message}");
                lstOnlineUsers.Items.Clear();
                lstOnlineUsers.Items.Add("❌ Помилка завантаження");
                lstOnlineUsers.BackColor = clrBackground;
                lstOnlineUsers.ForeColor = clrText;
            }
        }

        private void ProcessReceivedPacket(NetworkPacket packet)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<NetworkPacket>(ProcessReceivedPacket), packet);
                return;
            }

            try
            {
                Console.WriteLine($"Отримано пакет типу: {packet.Type}");

                switch (packet.Type)
                {
                    case "Message":
                        string messageJson = JsonConvert.SerializeObject(packet.Data);
                        Message message = JsonConvert.DeserializeObject<Message>(messageJson);
                        Console.WriteLine($"Отримано повідомлення: {message.Sender}: {message.Content}");
                        DisplayNewMessage(message);
                        break;

                    case "File":
                        string fileJson = JsonConvert.SerializeObject(packet.Data);
                        FileMessage fileMessage = JsonConvert.DeserializeObject<FileMessage>(fileJson);
                        Console.WriteLine($"Отримано файл: {fileMessage.Sender}: {fileMessage.FileName}");
                        DisplayFileMessage(fileMessage);
                        break;

                    case "ONLINE_USERS":
                        string onlineUsersString = packet.Data?.ToString() ?? "";
                        Console.WriteLine($"📊 Отримано список онлайн: '{onlineUsersString}'");
                        UpdateOnlineUsersFromString(onlineUsersString);
                        break;

                    case "LoginSuccess":
                        Console.WriteLine("✅ Отримано LoginSuccess");
                        AddSystemMessage("Успішний вхід в систему");
                        RequestOnlineUsers();
                        break;

                    case "MessageHistory":
                        string historyJson = JsonConvert.SerializeObject(packet.Data);
                        List<object> history = JsonConvert.DeserializeObject<List<object>>(historyJson);
                        Console.WriteLine($"Отримано історію: {history.Count} повідомлень");
                        DisplayMessageHistory(history);
                        break;

                    case "LoginFailed":
                        string errorMessage = packet.Data?.ToString() ?? "Невідома помилка";
                        Console.WriteLine($"Помилка входу: {errorMessage}");
                        AddSystemMessage($"Помилка входу: {errorMessage}");
                        break;

                    case "RegisterSuccess":
                        Console.WriteLine("Реєстрація успішна");
                        AddSystemMessage("Реєстрація успішна");
                        break;

                    case "RegisterFailed":
                        string registerError = packet.Data?.ToString() ?? "Невідома помилка";
                        Console.WriteLine($"Помилка реєстрації: {registerError}");
                        AddSystemMessage($"Помилка реєстрації: {registerError}");
                        break;

                    case "CallRequest":
                        string caller = packet.Sender;
                        Console.WriteLine($"📞 Отримано запит на дзвінок від: {caller}");
                        HandleCallRequest(caller);
                        break;

                    case "CallAccept":
                        string acceptor = packet.Sender;
                        Console.WriteLine($"✅ Користувач {acceptor} прийняв дзвінок");
                        HandleCallAccept(acceptor);
                        break;

                    case "CallReject":
                        string rejector = packet.Sender;
                        Console.WriteLine($"❌ Користувач {rejector} відхилив дзвінок");
                        HandleCallReject(rejector);
                        break;

                    case "CallEnd":
                        string ender = packet.Sender;
                        Console.WriteLine($"📞 Користувач {ender} завершив дзвінок");
                        HandleCallEnd(ender);
                        break;

                    default:
                        Console.WriteLine($"Невідомий тип пакета: {packet.Type}");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка обробки пакета: {ex.Message}");
            }
        }

        private void TryRegisterAndLogin(string serverIP, string username, string password)
        {
            try
            {
                Console.WriteLine($"Спроба підключення до {serverIP}:8888...");
                _client = new TcpClient();
                _client.Connect(serverIP, 8888);
                _stream = _client.GetStream();
                _isConnected = true;

                Console.WriteLine("Підключення успішне, спроба реєстрації...");

                var registerData = new
                {
                    Username = username,
                    Password = password
                };

                var registerPacket = new NetworkPacket("Register", registerData);
                byte[] registerDataBytes = NetworkSerializer.Serialize(registerPacket);

                Console.WriteLine($"Відправляємо register пакет...");
                _stream.Write(registerDataBytes, 0, registerDataBytes.Length);
                Console.WriteLine("Register пакет відправлено");

                Thread.Sleep(1000);

                var loginData = new
                {
                    Username = username,
                    Password = password
                };

                var loginPacket = new NetworkPacket("Login", loginData);
                byte[] loginDataBytes = NetworkSerializer.Serialize(loginPacket);

                Console.WriteLine($"Відправляємо login пакет...");
                _stream.Write(loginDataBytes, 0, loginDataBytes.Length);
                Console.WriteLine("Login пакет відправлено");

                _username = username;

                Thread receiveThread = new Thread(ReceiveData);
                receiveThread.IsBackground = true;
                receiveThread.Start();
                Console.WriteLine("Потік отримання даних запущено");

                this.Text = $"BlueChat - {username}";
                btnSend.Enabled = true;
                btnFile.Enabled = true;
                btnVideoCall.Enabled = true;

                UpdateStatus("Підключено");
                AddSystemMessage("Підключено до сервера");
                Console.WriteLine("UI оновлено");
            }
            catch (Exception ex)
            {
                UpdateStatus("Відключено");
                Console.WriteLine($"ПОМИЛКА підключення: {ex.Message}");
                MessageBox.Show($"Помилка підключення: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
        }

        private void RequestOnlineUsers()
        {
            try
            {
                if (!_isConnected || _stream == null)
                {
                    Console.WriteLine("❌ Не можу відправити запит - немає підключення");
                    return;
                }

                var packet = new NetworkPacket("GetOnlineUsers", null);
                byte[] data = NetworkSerializer.Serialize(packet);
                _stream.Write(data, 0, data.Length);
                Console.WriteLine("📨 Запит списку онлайн користувачів відправлено на сервер");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка запиту онлайн користувачів: {ex.Message}");
            }
        }

        private void DisplayMessageHistory(List<object> history)
        {
            try
            {
                if (txtChat.InvokeRequired)
                {
                    txtChat.Invoke(new Action<List<object>>(DisplayMessageHistory), history);
                    return;
                }

                txtChat.Clear();
                AddSystemMessage($"Завантажено історію чату ({history.Count} повідомлень)");

                foreach (var item in history)
                {
                    string json = JsonConvert.SerializeObject(item);
                    var obj = JsonConvert.DeserializeObject<dynamic>(json);

                    string messageType = obj.MessageType?.ToString() ?? "Text";

                    if (messageType == "File")
                    {
                        string sender = obj.Sender?.ToString() ?? "Невідомо";
                        string fileName = obj.FileName?.ToString() ?? "файл";
                        string timestamp = obj.Timestamp?.ToString() ?? DateTime.Now.ToString();

                        string fileDisplay = $"[{DateTime.Parse(timestamp):HH:mm}] {sender}: 📎 {fileName}\r\n";
                        txtChat.AppendText(fileDisplay);
                    }
                    else
                    {
                        string sender = obj.Sender?.ToString() ?? "Невідомо";
                        string content = obj.Content?.ToString() ?? "";
                        string timestamp = obj.Timestamp?.ToString() ?? DateTime.Now.ToString();

                        string messageDisplay = $"[{DateTime.Parse(timestamp):HH:mm}] {sender}: {content}\r\n";
                        txtChat.AppendText(messageDisplay);
                    }
                }

                AddSystemMessage("--- Кінець історії ---");
                txtChat.ScrollToCaret();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка відображення історії: {ex.Message}");
                AddSystemMessage("Помилка завантаження історії");
            }
        }

        private void DisplayNewMessage(Message message)
        {
            try
            {
                string displayText = $"[{message.Timestamp:HH:mm}] {message.Sender}: {message.Content}\r\n";

                if (txtChat.InvokeRequired)
                {
                    txtChat.Invoke(new Action(() => {
                        txtChat.AppendText(displayText);
                        txtChat.ScrollToCaret();
                    }));
                }
                else
                {
                    txtChat.AppendText(displayText);
                    txtChat.ScrollToCaret();
                }

                Console.WriteLine($"Повідомлення додано в чат: {message.Sender}: {message.Content}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка DisplayNewMessage: {ex.Message}");
            }
        }

        private void AddSystemMessage(string text)
        {
            string displayText = $"[Система] {text}\r\n";
            txtChat.AppendText(displayText);
        }

        private void HandleCallRequest(string caller)
        {
            DialogResult result = MessageBox.Show($"Користувач {caller} дзвонить вам. Прийняти дзвінок?",
                "Вхідний дзвінок", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            try
            {
                if (result == DialogResult.Yes)
                {
                    var acceptPacket = new NetworkPacket("CallAccept", new { Target = caller })
                    {
                        Sender = _username
                    };
                    byte[] data = NetworkSerializer.Serialize(acceptPacket);
                    _stream.Write(data, 0, data.Length);

                    StartVideoCall(caller);
                    Console.WriteLine($"✅ Прийнято дзвінок від {caller}");
                }
                else
                {
                    var rejectPacket = new NetworkPacket("CallReject", new { Target = caller })
                    {
                        Sender = _username
                    };
                    byte[] data = NetworkSerializer.Serialize(rejectPacket);
                    _stream.Write(data, 0, data.Length);

                    Console.WriteLine($"❌ Відхилено дзвінок від {caller}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка обробки вхідного дзвінка: {ex.Message}");
            }
        }

        private void HandleCallAccept(string targetUser)
        {
            MessageBox.Show($"Користувач {targetUser} прийняв ваш дзвінок",
                "Дзвінок прийнято", MessageBoxButtons.OK, MessageBoxIcon.Information);

            StartVideoCall(targetUser);
            Console.WriteLine($"✅ Дзвінок з {targetUser} розпочато");
        }

        private void HandleCallReject(string targetUser)
        {
            MessageBox.Show($"Користувач {targetUser} відхилив ваш дзвінок",
                "Дзвінок відхилено", MessageBoxButtons.OK, MessageBoxIcon.Information);

            Console.WriteLine($"❌ Дзвінок з {targetUser} відхилено");
        }

        private void HandleCallEnd(string targetUser)
        {
            MessageBox.Show($"Користувач {targetUser} завершив дзвінок",
                "Дзвінок завершено", MessageBoxButtons.OK, MessageBoxIcon.Information);

            StopVideoCall();
            Console.WriteLine($"📞 Дзвінок з {targetUser} завершено");
        }

        private void lstOnlineUsers_DoubleClick(object sender, EventArgs e)
        {
            if (lstOnlineUsers.SelectedItem != null)
            {
                string selectedUserText = lstOnlineUsers.SelectedItem.ToString();
                string selectedUsername = selectedUserText.Split(' ')[0];

                if (!string.IsNullOrEmpty(selectedUsername) && selectedUsername != _currentUser?.Username)
                {
                    StartVideoCallWithUser(selectedUsername);
                }
            }
        }

        private void btnVideoCall_Click(object sender, EventArgs e)
        {
            if (lstOnlineUsers.SelectedItem != null)
            {
                string selectedUserText = lstOnlineUsers.SelectedItem.ToString();
                string selectedUsername = selectedUserText.Split(' ')[0];
                StartVideoCallWithUser(selectedUsername);
            }
            else
            {
                MessageBox.Show("Виберіть користувача для дзвінка", "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void StartVideoCallWithUser(string targetUser)
        {
            try
            {
                if (!_isConnected || _stream == null)
                {
                    MessageBox.Show("Немає підключення до сервера", "Помилка");
                    return;
                }

                Console.WriteLine($"📞 Відправляю запит на відеодзвінок до: {targetUser}");

                var callPacket = new NetworkPacket("CallRequest", new { Target = targetUser })
                {
                    Sender = _username
                };

                byte[] data = NetworkSerializer.Serialize(callPacket);
                _stream.Write(data, 0, data.Length);

                MessageBox.Show($"Виклик користувачу {targetUser} відправлено...", "Виклик",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                Console.WriteLine($"✅ Запит на дзвінок відправлено до {targetUser}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка відправки запиту на дзвінок: {ex.Message}");
                MessageBox.Show($"Помилка відправки запиту: {ex.Message}", "Помилка");
            }
        }

        private void btnEndCall_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(_currentCallWith))
            {
                var endCallPacket = new NetworkPacket("CallEnd", _currentUser) { Sender = _currentCallWith };
                byte[] data = NetworkSerializer.Serialize(endCallPacket);
                _stream.Write(data, 0, data.Length);

                StopVideoCall();
            }
        }

        private bool IsConnectedToServer()
        {
            return _isConnected && _client != null && _client.Connected;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (!IsConnectedToServer())
            {
                MessageBox.Show("Немає підключення до сервера", "Помилка");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtMessage.Text))
            {
                MessageBox.Show("Введіть повідомлення", "Помилка");
                return;
            }

            try
            {
                string messageText = txtMessage.Text;
                Message message = new Message(_username, messageText);

                var packet = new NetworkPacket("Message", message);
                byte[] data = NetworkSerializer.Serialize(packet);
                _stream.Write(data, 0, data.Length);

                Console.WriteLine($"Повідомлення відправлено на сервер: {messageText}");
                txtMessage.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка відправки: {ex.Message}", "Помилка");
                HandleDisconnection();
            }
        }

        private void btnFile_Click(object sender, EventArgs e)
        {
            if (!IsConnectedToServer())
            {
                MessageBox.Show("Немає підключення до сервера", "Помилка");
                return;
            }

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Multiselect = false;
                openFileDialog.Title = "Виберіть файл для відправки";
                openFileDialog.Filter = "Всі файли (*.*)|*.*|Зображення (*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif|Текстові файли (*.txt)|*.txt";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string filePath = openFileDialog.FileName;
                        string fileName = Path.GetFileName(filePath);
                        long fileSize = new FileInfo(filePath).Length;

                        if (fileSize > 10 * 1024 * 1024)
                        {
                            MessageBox.Show("Файл занадто великий. Максимальний розмір: 10MB", "Помилка");
                            return;
                        }

                        byte[] fileData = File.ReadAllBytes(filePath);
                        SendFile(fileName, fileData);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Помилка читання файлу: {ex.Message}", "Помилка");
                    }
                }
            }
        }

        private void SendFile(string fileName, byte[] fileData)
        {
            try
            {
                var fileMessage = new FileMessage(_username, fileName, fileData);
                var packet = new NetworkPacket("File", fileMessage);
                byte[] data = NetworkSerializer.Serialize(packet);
                _stream.Write(data, 0, data.Length);

                Console.WriteLine($"Файл відправлено на сервер: {fileName} ({fileData.Length} байт)");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка відправки файлу: {ex.Message}", "Помилка");
            }
        }

        private void txtMessage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnSend_Click(sender, e);
                e.Handled = true;
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopVideoCapture();

            if (_isConnected && _currentUser != null)
            {
                var logoutPacket = new NetworkPacket("Logout", _currentUser);
                byte[] data = NetworkSerializer.Serialize(logoutPacket);
                _stream.Write(data, 0, data.Length);

                _isConnected = false;
                _stream?.Close();
                _client?.Close();
            }
        }

        private void LoadMessageHistory()
        {
            try
            {
                var historyPacket = new NetworkPacket("GetHistory", null);
                byte[] data = NetworkSerializer.Serialize(historyPacket);
                _stream.Write(data, 0, data.Length);
                Console.WriteLine("Запит історії відправлено");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка завантаження історії: {ex.Message}");
            }
        }

        private void DisplayMessageHistory(List<Message> history)
        {
            try
            {
                if (txtChat.InvokeRequired)
                {
                    txtChat.Invoke(new Action<List<Message>>(DisplayMessageHistory), history);
                    return;
                }

                txtChat.Clear();
                AddSystemMessage($"--- Завантажено історію повідомлень ({history.Count}) ---");

                foreach (var message in history)
                {
                    string displayText = $"[{message.Timestamp:HH:mm}] {message.Sender}: {message.Content}\r\n";
                    txtChat.AppendText(displayText);
                }

                AddSystemMessage("--- Кінець історії ---");
                txtChat.ScrollToCaret();

                Console.WriteLine($"Відображено {history.Count} повідомлень з історії");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка відображення історії: {ex.Message}");
            }
        }

        private void DisplayFileMessage(FileMessage fileMessage)
        {
            try
            {
                if (txtChat.InvokeRequired)
                {
                    txtChat.Invoke(new Action<FileMessage>(DisplayFileMessage), fileMessage);
                    return;
                }

                string fileDisplay = $"[{fileMessage.Timestamp:HH:mm}] {fileMessage.Sender}: 📎 ";
                txtChat.AppendText(fileDisplay);

                int startPos = txtChat.TextLength;
                txtChat.AppendText($"{fileMessage.FileName} ({FormatFileSize(fileMessage.FileSize)})");
                int endPos = txtChat.TextLength;

                FileLink fileLink = new FileLink
                {
                    StartPosition = startPos,
                    EndPosition = endPos,
                    FileMessage = fileMessage
                };

                _fileLinks.Add(fileLink);
                txtChat.AppendText("\r\n");
                txtChat.ScrollToCaret();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка відображення файлу: {ex.Message}");
            }
        }

        private void AskToSaveFile(FileMessage fileMessage)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<FileMessage>(AskToSaveFile), fileMessage);
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Зберегти файл '{fileMessage.FileName}' ({FormatFileSize(fileMessage.FileSize)})?",
                "Отримано файл",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                SaveFileWithDialog(fileMessage);
            }
        }

        private string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            int order = 0;
            double len = bytes;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }
            return $"{len:0.##} {sizes[order]}";
        }

        private void SaveFileWithDialog(FileMessage fileMessage)
        {
            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.FileName = fileMessage.FileName;
                saveDialog.Filter = "Всі файли (*.*)|*.*";
                saveDialog.Title = "Зберегти файл";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllBytes(saveDialog.FileName, fileMessage.FileData);
                        MessageBox.Show($"Файл збережено: {saveDialog.FileName}", "Успіх");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Помилка збереження: {ex.Message}", "Помилка");
                    }
                }
            }
        }
    }
}