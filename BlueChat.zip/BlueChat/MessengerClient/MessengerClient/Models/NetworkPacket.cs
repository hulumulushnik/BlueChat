﻿using System;

namespace MessengerClient.Models
{
    [Serializable]
    public class NetworkPacket
    {
        public string Type { get; set; }  // "Login", "Message", "Logout"
        public object Data { get; set; }
        public string Sender { get; set; }

        public NetworkPacket(string type, object data)
        {
            Type = type;
            Data = data;
            Sender = string.Empty;
        }
    }
}
