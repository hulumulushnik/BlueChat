﻿using MessengerServer.Models;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace MessengerServer
{
    public class MessengerServer
    {
        private TcpListener _listener;
        private List<ClientHandler> _clients = new List<ClientHandler>();
        private List<ChatRoom> _chatRooms = new List<ChatRoom>();
        private bool _isRunning = true;

        // Підключення до SQL бази
        private string _connectionString = "Server=DESKTOP-T07RBAC;Database=MessengerDB;Integrated Security=true;TrustServerCertificate=true;";

        // Додатковий клас для обробки клієнтів
        private class ClientHandler
        {
            public TcpClient Client { get; set; }
            public User User { get; set; }
            public NetworkStream Stream { get; set; }
        }

        public void Start()
        {
            try
            {
                // Ініціалізуємо базу даних при старті
                InitializeDatabase();

                // Створюємо головну кімнату чату
                _chatRooms.Add(new ChatRoom("General"));

                _listener = new TcpListener(IPAddress.Any, 8888);
                _listener.Start();
                Console.WriteLine("Сервер запущений на порті 8888...");

                while (_isRunning)
                {
                    var client = _listener.AcceptTcpClient();
                    AddClient(client);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка сервера: {ex.Message}");
            }
        }

        // Ініціалізація бази даних
        private void InitializeDatabase()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Перевіряємо чи існують таблиці, якщо ні - створюємо
                    string checkTablesQuery = @"
                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Users' AND xtype='U')
                        BEGIN
                            CREATE TABLE Users (
                                UserID INT IDENTITY(1,1) PRIMARY KEY,
                                Username NVARCHAR(50) UNIQUE NOT NULL,
                                Password NVARCHAR(100) NOT NULL,
                                IsOnline BIT DEFAULT 0,
                                LastLogin DATETIME NULL,
                                CreatedAt DATETIME DEFAULT GETDATE()
                            )
                        END
                        
                        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Messages' AND xtype='U')
                        BEGIN
                            CREATE TABLE Messages (
                                MessageID INT IDENTITY(1,1) PRIMARY KEY,
                                SenderID INT NOT NULL FOREIGN KEY REFERENCES Users(UserID),
                                MessageText NVARCHAR(MAX),
                                MessageType NVARCHAR(20) DEFAULT 'Text',
                                FileName NVARCHAR(255),
                                FileData VARBINARY(MAX),
                                Timestamp DATETIME DEFAULT GETDATE()
                            )
                        END";

                    using (SqlCommand command = new SqlCommand(checkTablesQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    Console.WriteLine("База даних ініціалізована");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка ініціалізації бази даних: {ex.Message}");
            }
        }

        private void AddClient(TcpClient client)
        {
            var clientHandler = new ClientHandler
            {
                Client = client,
                Stream = client.GetStream()
            };

            _clients.Add(clientHandler);
            Console.WriteLine($"Клієнт підключився: {client.Client.RemoteEndPoint}");
            Console.WriteLine($"Зараз підключено клієнтів: {_clients.Count}");

            Thread clientThread = new Thread(() => HandleClient(clientHandler));
            clientThread.IsBackground = true;
            clientThread.Start();
        }

        private void RemoveClient(ClientHandler clientHandler)
        {
            try
            {
                if (clientHandler.User != null)
                {
                    Console.WriteLine($"🔴 Видаляємо клієнта: {clientHandler.User.Username}");

                    // Оновлюємо статус в базі даних
                    UpdateUserOnlineStatus(clientHandler.User.Username, false);

                    Console.WriteLine($"Користувач {clientHandler.User.Username} відключився");

                    // Розсилаємо оновлені списки
                    BroadcastOnlineUsers();
                }

                // Безпечно закриваємо з'єднання
                if (clientHandler.Stream != null)
                {
                    clientHandler.Stream.Close();
                    clientHandler.Stream = null;
                }

                if (clientHandler.Client != null)
                {
                    clientHandler.Client.Close();
                    clientHandler.Client = null;
                }

                _clients.Remove(clientHandler);
                Console.WriteLine($"✅ Клієнт видалений. Залишилось: {_clients.Count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка при видаленні клієнта: {ex.Message}");
            }
        }

        // Оновлення статусу користувача в базі даних
        private void UpdateUserOnlineStatus(string username, bool isOnline)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Users SET IsOnline = @IsOnline, LastLogin = GETDATE() WHERE Username = @Username";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@IsOnline", isOnline);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка оновлення статусу користувача: {ex.Message}");
            }
        }

        private void BroadcastMessage(Message message)
        {
            try
            {
                Console.WriteLine($"BroadcastMessage: {message.Sender}: {message.Content}");

                // Зберігаємо повідомлення в базі даних
                SaveMessageToDatabase(message);

                var packet = new NetworkPacket("Message", message);
                Broadcast(packet);

                Console.WriteLine($"Повідомлення розіслано всім клієнтам");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка в BroadcastMessage: {ex.Message}");
            }
        }

        private void BroadcastFile(FileMessage fileMessage)
        {
            try
            {
                Console.WriteLine($"BroadcastFile: {fileMessage.Sender}: {fileMessage.FileName}");

                // Зберігаємо файл в базі даних
                SaveFileToDatabase(fileMessage);

                var packet = new NetworkPacket("File", fileMessage);
                Broadcast(packet);

                Console.WriteLine($"Файл розіслано всім клієнтам");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка в BroadcastFile: {ex.Message}");
            }
        }

        private void BroadcastUserList()
        {
            var onlineUsers = GetOnlineUsersFromDatabase();
            var packet = new NetworkPacket("UserList", onlineUsers);
            Broadcast(packet);
        }

        private void BroadcastOnlineUsers()
        {
            try
            {
                var onlineUsers = GetOnlineUsersFromDatabase();
                var userList = onlineUsers.Select(u => u.Username).ToList();
                string usersString = string.Join(",", userList);

                var packet = new NetworkPacket("ONLINE_USERS", usersString);
                Broadcast(packet);

                Console.WriteLine($"Розіслано список онлайн користувачів всім: {usersString} (кількість: {userList.Count})");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка розсилки онлайн користувачів: {ex.Message}");
            }
        }

        // Отримання онлайн користувачів з бази даних
        private List<User> GetOnlineUsersFromDatabase()
        {
            var onlineUsers = new List<User>();
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "SELECT Username, IPAddress FROM Users WHERE IsOnline = 1";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string username = reader["Username"].ToString();
                            string ip = reader["IPAddress"]?.ToString() ?? "Невідомо";
                            onlineUsers.Add(new User(username, ip));
                            Console.WriteLine($"Онлайн: {username} - {ip}");
                        }
                    }
                }
                Console.WriteLine($"Всього онлайн користувачів: {onlineUsers.Count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка отримання онлайн користувачів: {ex.Message}");
            }
            return onlineUsers;
        }

        private void SendToUser(string username, NetworkPacket packet)
        {
            var clientHandler = _clients.Find(c => c.User?.Username == username);
            if (clientHandler != null && clientHandler.Client.Connected)
            {
                try
                {
                    var data = NetworkSerializer.Serialize(packet);
                    clientHandler.Stream.Write(data, 0, data.Length);
                }
                catch
                {
                    RemoveClient(clientHandler);
                }
            }
        }

        private void Broadcast(NetworkPacket packet)
        {
            try
            {
                var data = NetworkSerializer.Serialize(packet);
                int clientsCount = 0;

                List<ClientHandler> disconnectedClients = new List<ClientHandler>();

                foreach (var clientHandler in _clients.ToArray())
                {
                    if (clientHandler.Client.Connected && clientHandler.Stream != null)
                    {
                        try
                        {
                            clientHandler.Stream.Write(data, 0, data.Length);
                            clientsCount++;
                            Console.WriteLine($"Відправлено клієнту: {clientHandler.User?.Username}");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Помилка відправки клієнту {clientHandler.User?.Username}: {ex.Message}");
                            disconnectedClients.Add(clientHandler);
                        }
                    }
                    else
                    {
                        disconnectedClients.Add(clientHandler);
                    }
                }

                Console.WriteLine($"Повідомлення розіслано {clientsCount} клієнтам");

                foreach (var client in disconnectedClients)
                {
                    RemoveClient(client);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка в Broadcast: {ex.Message}");
            }
        }

        private void HandleClient(ClientHandler clientHandler)
        {
            try
            {
                NetworkStream stream = clientHandler.Stream;
                byte[] buffer = new byte[4096];
                StringBuilder jsonBuilder = new StringBuilder();

                while (clientHandler.Client.Connected && _isRunning && stream != null)
                {
                    try
                    {
                        if (!stream.DataAvailable)
                        {
                            Thread.Sleep(50);
                            continue;
                        }

                        int bytesRead = stream.Read(buffer, 0, buffer.Length);

                        if (bytesRead == 0)
                        {
                            Console.WriteLine("Клієнт відключився (0 bytes)");
                            break;
                        }

                        if (bytesRead > 0)
                        {
                            string receivedData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                            jsonBuilder.Append(receivedData);

                            // Спробуємо знайти повні JSON об'єкти
                            string jsonString = jsonBuilder.ToString();
                            int startIndex = 0;

                            while (startIndex < jsonString.Length)
                            {
                                // Шукаємо початок JSON об'єкта
                                int objectStart = jsonString.IndexOf('{', startIndex);
                                if (objectStart == -1) break;

                                // Шукаємо кінець JSON об'єкта
                                int braceCount = 0;
                                int objectEnd = -1;

                                for (int i = objectStart; i < jsonString.Length; i++)
                                {
                                    if (jsonString[i] == '{') braceCount++;
                                    else if (jsonString[i] == '}') braceCount--;

                                    if (braceCount == 0)
                                    {
                                        objectEnd = i;
                                        break;
                                    }
                                }

                                if (objectEnd == -1) break; // Неповний JSON

                                // Виділяємо один JSON об'єкт
                                string singleJson = jsonString.Substring(objectStart, objectEnd - objectStart + 1);
                                startIndex = objectEnd + 1;

                                try
                                {
                                    Console.WriteLine($"Десеріалізація JSON: {singleJson}");
                                    var packet = NetworkSerializer.Deserialize<NetworkPacket>(singleJson);
                                    if (packet != null)
                                    {
                                        ProcessPacket(packet, clientHandler);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine($"Помилка десеріалізації: {ex.Message}");
                                }
                            }

                            // Зберігаємо залишок для наступного читання
                            if (startIndex < jsonString.Length)
                            {
                                jsonBuilder = new StringBuilder(jsonString.Substring(startIndex));
                            }
                            else
                            {
                                jsonBuilder.Clear();
                            }
                        }
                    }
                    catch (IOException ioEx)
                    {
                        Console.WriteLine($"IO помилка: {ioEx.Message}");
                        break;
                    }
                    catch (ObjectDisposedException)
                    {
                        Console.WriteLine("Stream вже видалений");
                        break;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Помилка обробки клієнта: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Критична помилка обробки клієнта: {ex.Message}");
            }
            finally
            {
                RemoveClient(clientHandler);
            }
        }

        private void ProcessPacket(NetworkPacket packet, ClientHandler clientHandler)
        {
            try
            {
                Console.WriteLine($"Обробка пакета типу: {packet.Type}");

                switch (packet.Type)
                {
                    case "Login":
                        HandleLogin(packet, clientHandler);
                        break;

                    case "Register":
                        HandleRegister(packet, clientHandler);
                        break;

                    case "Message":
                        HandleMessage(packet, clientHandler);
                        break;

                    case "File":
                        HandleFile(packet, clientHandler);
                        break;

                    case "GetHistory":
                        SendMessageHistory(clientHandler);
                        break;

                    case "GetOnlineUsers":
                        Console.WriteLine("📨 Отримано запит на список онлайн користувачів");
                        SendOnlineUsers(clientHandler);
                        break;

                    case "CallRequest":
                    case "CallAccept":
                    case "CallReject":
                    case "CallEnd":
                        Console.WriteLine($"📞 Пересилання дзвінка: {packet.Type}");
                        HandleCall(packet, clientHandler);
                        break;

                    case "Logout":
                        Console.WriteLine("Обробка Logout...");
                        RemoveClient(clientHandler);
                        break;

                    default:
                        Console.WriteLine($"Невідомий тип пакета: {packet.Type}");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка в ProcessPacket: {ex.Message}");
            }
        }

        // Обробка входу користувача
        private void HandleLogin(NetworkPacket packet, ClientHandler clientHandler)
        {
            try
            {
                string userJson = JsonConvert.SerializeObject(packet.Data);
                var loginData = JsonConvert.DeserializeObject<dynamic>(userJson);
                string username = loginData.Username;
                string password = loginData.Password;

                if (ValidateUserInDatabase(username, password))
                {
                    var user = new User(username, ((IPEndPoint)clientHandler.Client.Client.RemoteEndPoint).Address.ToString());
                    user.IsOnline = true;
                    clientHandler.User = user;

                    // Оновлюємо статус в базі даних
                    UpdateUserOnlineStatus(username, true);

                    // Надсилаємо підтвердження
                    var successPacket = new NetworkPacket("LoginSuccess", user);
                    SendToClient(successPacket, clientHandler);

                    // НЕГАЙНО надсилаємо список онлайн користувачів новому клієнту
                    SendOnlineUsers(clientHandler);

                    // ТАКОЖ розсилаємо оновлений список ВСІМ клієнтам
                    BroadcastOnlineUsers();

                    Console.WriteLine($"Користувач {username} успішно увійшов. Онлайн: {_clients.Count} користувачів");
                }
                else
                {
                    var errorPacket = new NetworkPacket("LoginFailed", "Невірний логін або пароль");
                    SendToClient(errorPacket, clientHandler);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка обробки входу: {ex.Message}");
                var errorPacket = new NetworkPacket("Error", "Помилка сервера");
                SendToClient(errorPacket, clientHandler);
            }
        }

        // Обробка реєстрації
        private void HandleRegister(NetworkPacket packet, ClientHandler clientHandler)
        {
            try
            {
                string userJson = JsonConvert.SerializeObject(packet.Data);
                var registerData = JsonConvert.DeserializeObject<dynamic>(userJson);
                string username = registerData.Username;
                string password = registerData.Password;

                Console.WriteLine($"Спроба реєстрації: {username}");

                if (RegisterUserInDatabase(username, password))
                {
                    var successPacket = new NetworkPacket("RegisterSuccess", "Реєстрація успішна");
                    SendToClient(successPacket, clientHandler);
                    Console.WriteLine($"✅ Користувач {username} успішно зареєстрований");

                    // Автоматично оновлюємо статус онлайн
                    UpdateUserOnlineStatus(username, true);
                }
                else
                {
                    var errorPacket = new NetworkPacket("RegisterFailed", "Користувач вже існує");
                    SendToClient(errorPacket, clientHandler);
                    Console.WriteLine($"❌ Реєстрація не вдала: {username} вже існує");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка обробки реєстрації: {ex.Message}");
                var errorPacket = new NetworkPacket("Error", "Помилка сервера при реєстрації");
                SendToClient(errorPacket, clientHandler);
            }
        }

        // Обробка повідомлення
        private void HandleMessage(NetworkPacket packet, ClientHandler clientHandler)
        {
            try
            {
                string messageJson = JsonConvert.SerializeObject(packet.Data);
                Message message = JsonConvert.DeserializeObject<Message>(messageJson);

                // Встановлюємо відправника
                if (clientHandler.User != null)
                {
                    message.Sender = clientHandler.User.Username;
                    message.Timestamp = DateTime.Now; // Оновлюємо timestamp
                }

                Console.WriteLine($"Обробка повідомлення від {message.Sender}: {message.Content}");

                // Зберігаємо в базі даних та розсилаємо
                BroadcastMessage(message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка обробки повідомлення: {ex.Message}");
            }
        }

        // Обробка файлу
        private void HandleFile(NetworkPacket packet, ClientHandler clientHandler)
        {
            try
            {
                string fileJson = JsonConvert.SerializeObject(packet.Data);
                FileMessage fileMessage = JsonConvert.DeserializeObject<FileMessage>(fileJson);

                // Встановлюємо відправника
                if (clientHandler.User != null)
                {
                    fileMessage.Sender = clientHandler.User.Username;
                }

                // Зберігаємо файл в базі даних
                SaveFileToDatabase(fileMessage);

                // Розсилаємо всім клієнтам
                BroadcastFile(fileMessage);
                Console.WriteLine($"Файл від {fileMessage.Sender}: {fileMessage.FileName} ({fileMessage.FileSize} байт)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка обробки файлу: {ex.Message}");
            }
        }

        // Обробка дзвінка
        private void HandleCall(NetworkPacket packet, ClientHandler clientHandler)
        {
            try
            {
                if (!string.IsNullOrEmpty(packet.Sender) && clientHandler.User != null)
                {
                    Console.WriteLine($"📞 Обробка дзвінка {packet.Type} від {clientHandler.User.Username} до {packet.Sender}");

                    var callPacket = new NetworkPacket(packet.Type, packet.Data)
                    {
                        Sender = clientHandler.User.Username
                    };

                    SendToUser(packet.Sender, callPacket);
                    Console.WriteLine($"✅ Дзвінок {packet.Type} відправлено від {clientHandler.User.Username} до {packet.Sender}");
                }
                else
                {
                    Console.WriteLine($"❌ Помилка дзвінка: відправник або отримувач не визначені");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Помилка обробки дзвінка: {ex.Message}");
            }
        }

        // Перевірка користувача в базі даних
        private bool ValidateUserInDatabase(string username, string password)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "SELECT UserID FROM Users WHERE Username = @Username AND Password = @Password";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Password", password ?? ""); // Додайте перевірку на null
                        return command.ExecuteScalar() != null;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка перевірки користувача: {ex.Message}");
                return false;
            }
        }

        // Реєстрація нового користувача
        private bool RegisterUserInDatabase(string username, string password)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Users (Username, Password) VALUES (@Username, @Password)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Password", password);
                        int rowsAffected = command.ExecuteNonQuery();
                        Console.WriteLine($"Реєстрація: {username}, рядків змінено: {rowsAffected}");
                        return rowsAffected > 0;
                    }
                }
            }
            catch (SqlException ex) when (ex.Number == 2627) // Duplicate key
            {
                Console.WriteLine($"Користувач {username} вже існує в базі");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка реєстрації користувача {username}: {ex.Message}");
                return false;
            }
        }
        // Збереження повідомлення в базу даних
        private void SaveMessageToDatabase(Message message)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Отримуємо UserID відправника
                    string getUserQuery = "SELECT UserID FROM Users WHERE Username = @Username";
                    int senderId;

                    using (SqlCommand getUserCmd = new SqlCommand(getUserQuery, connection))
                    {
                        getUserCmd.Parameters.AddWithValue("@Username", message.Sender);
                        var result = getUserCmd.ExecuteScalar();
                        if (result == null) return;
                        senderId = (int)result;
                    }

                    // Зберігаємо повідомлення
                    string insertQuery = @"INSERT INTO Messages (SenderID, MessageText, MessageType, Timestamp) 
                                         VALUES (@SenderID, @MessageText, @MessageType, @Timestamp)";

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@SenderID", senderId);
                        command.Parameters.AddWithValue("@MessageText", message.Content);
                        command.Parameters.AddWithValue("@MessageType", "Text");
                        command.Parameters.AddWithValue("@Timestamp", message.Timestamp);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка збереження повідомлення в базу: {ex.Message}");
            }
        }

        // Збереження файлу в базу даних
        private void SaveFileToDatabase(FileMessage fileMessage)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Отримуємо UserID відправника
                    string getUserQuery = "SELECT UserID FROM Users WHERE Username = @Username";
                    int senderId;

                    using (SqlCommand getUserCmd = new SqlCommand(getUserQuery, connection))
                    {
                        getUserCmd.Parameters.AddWithValue("@Username", fileMessage.Sender);
                        var result = getUserCmd.ExecuteScalar();
                        if (result == null) return;
                        senderId = (int)result;
                    }

                    // Зберігаємо файл
                    string insertQuery = @"INSERT INTO Messages (SenderID, MessageText, MessageType, FileName, FileData, Timestamp) 
                                         VALUES (@SenderID, @MessageText, @MessageType, @FileName, @FileData, @Timestamp)";

                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@SenderID", senderId);
                        command.Parameters.AddWithValue("@MessageText", $"Файл: {fileMessage.FileName}");
                        command.Parameters.AddWithValue("@MessageType", "File");
                        command.Parameters.AddWithValue("@FileName", fileMessage.FileName);
                        command.Parameters.AddWithValue("@FileData", fileMessage.FileData ?? new byte[0]);
                        command.Parameters.AddWithValue("@Timestamp", fileMessage.Timestamp);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка збереження файлу в базу: {ex.Message}");
            }
        }

        // Надсилання історії повідомлень клієнту
        private void SendMessageHistory(ClientHandler clientHandler)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string query = @"SELECT TOP 100 m.MessageID, u.Username as Sender, m.MessageText as Content, 
                           m.MessageType, m.FileName, m.FileData, m.Timestamp
                           FROM Messages m
                           INNER JOIN Users u ON m.SenderID = u.UserID
                           ORDER BY m.Timestamp DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        var history = new List<object>();

                        while (reader.Read())
                        {
                            string messageType = reader["MessageType"].ToString();

                            if (messageType == "Text")
                            {
                                var message = new Message(
                                    reader["Sender"].ToString(),
                                    reader["Content"].ToString()
                                )
                                {
                                    Timestamp = (DateTime)reader["Timestamp"]
                                };
                                history.Add(message);
                            }
                            else if (messageType == "File")
                            {
                                // Безпечне читання FileData
                                byte[] fileData = new byte[0];
                                if (reader["FileData"] != DBNull.Value)
                                {
                                    fileData = (byte[])reader["FileData"];
                                }

                                var fileMessage = new FileMessage(
                                    reader["Sender"].ToString(),
                                    reader["FileName"].ToString(),
                                    fileData
                                )
                                {
                                    Timestamp = (DateTime)reader["Timestamp"]
                                };
                                history.Add(fileMessage);
                            }
                        }

                        // Надсилаємо історію клієнту
                        var historyPacket = new NetworkPacket("MessageHistory", history);
                        SendToClient(historyPacket, clientHandler);
                        Console.WriteLine($"Відправлено {history.Count} повідомлень з історії");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка завантаження історії з SQL: {ex.Message}");
            }
        }

        // Надсилання списку онлайн користувачів
        private void SendOnlineUsers(ClientHandler clientHandler)
        {
            try
            {
                var onlineUsers = GetOnlineUsersFromDatabase();
                var userList = onlineUsers.Select(u => u.Username).ToList();
                string usersString = string.Join(",", userList);

                var packet = new NetworkPacket("ONLINE_USERS", usersString);
                SendToClient(packet, clientHandler);

                Console.WriteLine($"Відправлено список онлайн користувачів {clientHandler.User?.Username}: {usersString}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка відправки онлайн користувачів: {ex.Message}");
            }
        }

        // Розсилка списку онлайн користувачів всім клієнтам
        private void SendOnlineUsersToAll()
        {
            try
            {
                var onlineUsers = GetOnlineUsersFromDatabase();
                var userList = onlineUsers.Select(u => u.Username).ToList();
                string usersString = string.Join(",", userList);

                var packet = new NetworkPacket("ONLINE_USERS", usersString);
                Broadcast(packet);

                Console.WriteLine($"Розіслано список онлайн користувачів: {usersString}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка розсилки онлайн користувачів: {ex.Message}");
            }
        }

        private void SendToClient(NetworkPacket packet, ClientHandler clientHandler)
        {
            if (clientHandler.Client.Connected)
            {
                try
                {
                    var data = NetworkSerializer.Serialize(packet);
                    Console.WriteLine($"📤 Відправляю клієнту {clientHandler.User?.Username}: {packet.Type}, {data.Length} байт");
                    clientHandler.Stream.Write(data, 0, data.Length);
                    Console.WriteLine($"✅ Відправлено успішно");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Помилка відправки клієнту: {ex.Message}");
                    RemoveClient(clientHandler);
                }
            }
        }

        public void Stop()
        {
            _isRunning = false;

            // Оновлюємо статуси всіх користувачів на офлайн
            UpdateAllUsersOffline();

            _listener?.Stop();
            foreach (var clientHandler in _clients)
            {
                clientHandler.Client.Close();
            }
            _clients.Clear();

            Console.WriteLine("Сервер зупинено");
        }

        // Оновлення статусу всіх користувачів на офлайн при зупинці сервера
        private void UpdateAllUsersOffline()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Users SET IsOnline = 0";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                Console.WriteLine("Всі користувачі переведені в офлайн режим");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка оновлення статусів користувачів: {ex.Message}");
            }
        }
    }

    // Програма для запуску сервера
    public class Program
    {
        public static void Main(string[] args)
        {
            var server = new MessengerServer();

            Console.WriteLine("Запуск сервера месенджера...");
            Console.WriteLine("Натисніть 'q' для виходу");

            Thread serverThread = new Thread(server.Start);
            serverThread.IsBackground = true;
            serverThread.Start();

            while (true)
            {
                var key = Console.ReadKey(true);
                if (key.KeyChar == 'q' || key.KeyChar == 'Q')
                {
                    server.Stop();
                    break;
                }
            }
        }
    }
}