﻿using Newtonsoft.Json;
using System.Text;


namespace MessengerServer
{
    public static class NetworkSerializer
    {
        public static byte[] Serialize(object obj)
        {
            try
            {
                string json = JsonConvert.SerializeObject(obj);
                Console.WriteLine($"Серіалізовано JSON: {json}");
                return Encoding.UTF8.GetBytes(json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка серіалізації: {ex.Message}");
                return new byte[0];
            }
        }

        public static T Deserialize<T>(string json)
        {
            try
            {
                Console.WriteLine($"Десеріалізація JSON: {json}");
                return JsonConvert.DeserializeObject<T>(json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка десеріалізації: {ex.Message}");
                return default(T);
            }
        }

        // Старий метод для сумісності
        public static T Deserialize<T>(byte[] data)
        {
            string json = Encoding.UTF8.GetString(data);
            return Deserialize<T>(json);
        }
    }
}
