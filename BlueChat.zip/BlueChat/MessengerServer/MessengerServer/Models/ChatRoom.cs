﻿
namespace MessengerServer.Models
{
    [Serializable]
    public class ChatRoom
    {
        public string Name { get; set; }
        public List<User> Members { get; set; }
        public List<Message> Messages { get; set; }

        public ChatRoom(string name)
        {
            Name = name;
            Members = new List<User>();
            Messages = new List<Message>();
        }
    }
}
