﻿using System;
using System.IO;

[Serializable]
public class FileMessage
{
    public string Sender { get; set; }
    public string FileName { get; set; }
    public long FileSize { get; set; }
    public byte[] FileData { get; set; }
    public string FileType { get; set; }
    public DateTime Timestamp { get; set; }

    public FileMessage(string sender, string fileName, byte[] fileData)
    {
        Sender = sender;
        FileName = fileName;
        FileData = fileData;
        FileSize = fileData.Length;
        FileType = GetFileType(Path.GetExtension(fileName));
        Timestamp = DateTime.Now;
    }

    private string GetFileType(string extension)
    {
        if (string.IsNullOrEmpty(extension))
            return "File";

        string ext = extension.ToLower();

        switch (ext)
        {
            case ".jpg":
            case ".jpeg":
            case ".png":
            case ".gif":
            case ".bmp":
                return "Image";
            case ".txt":
                return "Text";
            case ".pdf":
                return "PDF";
            case ".doc":
            case ".docx":
                return "Word";
            case ".xls":
            case ".xlsx":
                return "Excel";
            case ".zip":
            case ".rar":
                return "Archive";
            default:
                return "File";
        }
    }

    public override string ToString()
    {
        return $"[{Timestamp:HH:mm}] {Sender}: 📎 {FileName} ({FormatFileSize(FileSize)})";
    }

    private string FormatFileSize(long bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB" };
        int order = 0;
        double len = bytes;
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len /= 1024;
        }
        return $"{len:0.##} {sizes[order]}";
    }
}
