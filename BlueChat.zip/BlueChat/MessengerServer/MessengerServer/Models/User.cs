﻿using System;

namespace MessengerServer.Models
{
    [Serializable]
    public class User
    {
        public string Username { get; set; }
        public string IPAddress { get; set; }
        public DateTime LastSeen { get; set; }
        public bool IsOnline { get; set; }

        public User(string username, string ipAddress)
        {
            Username = username;
            IPAddress = ipAddress;
            LastSeen = DateTime.Now;
            IsOnline = true;
        }
    }
}
